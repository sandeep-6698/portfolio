window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Gaana",
   "homepage": "https://gaana.com/",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": true,
   "enableLogoutBttn": false,
   "kioskEnabled": false
};